//
//  mParticle_Apple_SDK_NoLocation.h
//  mParticle-Apple-SDK-NoLocation
//
//  Created by Brandon Stalnaker on 10/18/23.
//

#ifndef mParticle_Apple_SDK_NoLocation_h
#define mParticle_Apple_SDK_NoLocation_h

#if defined(__has_include) && __has_include(<mParticle_Apple_SDK_NoLocation/mParticle.h>)
    #import <mParticle_Apple_SDK_NoLocation/mParticle.h>
#else
    #import "mParticle.h"
#endif

#endif /* mParticle_Apple_SDK_NoLocation_h */
