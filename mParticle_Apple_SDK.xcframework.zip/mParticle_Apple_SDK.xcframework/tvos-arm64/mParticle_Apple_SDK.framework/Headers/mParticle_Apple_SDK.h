//
//  mParticle_Apple_SDK.h
//  mParticle-Apple-SDK
//
//  Created by Brandon Stalnaker on 10/18/23.
//

#ifndef mParticle_Apple_SDK_h
#define mParticle_Apple_SDK_h

#if defined(__has_include) && __has_include(<mParticle_Apple_SDK/mParticle.h>)
    #import <mParticle_Apple_SDK/mParticle.h>
#else
    #import "mParticle.h"
#endif

#endif /* mParticle_Apple_SDK_h */
