#import "MPTransactionAttributes.h"

@interface MPTransactionAttributes(Dictionary)

- (NSDictionary *)dictionaryRepresentation;
- (NSDictionary *)beautifiedDictionaryRepresentation;

@end
